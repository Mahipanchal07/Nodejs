const express = require("express");
const db = require("./config/db");
const bookModel = require("./model/userModel"); 
const app = express();
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.post("/saveBook", async (req, res) => {
    const { bookName, author, publishedDate, price, bookId } = req.body;
    if (bookId) {
        try {
            await bookModel.findByIdAndUpdate(bookId, { bookName, author, publishedDate, price });
            res.redirect("/");
        } catch (error) {
            res.status(500).send("Error updating book");
        }
    } else {
        try {
            await bookModel.create({ bookName, author, publishedDate, price });
            res.redirect("/"); 
        } catch (error) {
            res.status(500).send("Error inserting book");
        }
    }
});
app.post("/deleteBook/:id", async (req, res) => {
    const bookId = req.params.id;
    try {
        await bookModel.findByIdAndDelete(bookId); 
        res.redirect("/"); 
    } catch (error) {
        res.status(500).send("Error deleting book");
    }
});
app.get("/", async (req, res) => {
    try {
        const books = await bookModel.find(); 
        const editBookId = req.query.editBookId; 
        let bookToEdit = null;
        if (editBookId) {
            bookToEdit = await bookModel.findById(editBookId);
        }
        res.render("signup", { books, bookToEdit, editBookId });
    } catch (error) {
        res.status(500).send("Error fetching books");
    }
});
app.listen(7867, () => {
    console.log("server listening");
});
