const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
    bookName: {
        type: String,
    },
    author: {
        type: String,
    },
    publishedDate: {
        type: Date
    },
    price: {
        type: String
    }
});

const bookModel = mongoose.model("Book", bookSchema);

module.exports = bookModel;
