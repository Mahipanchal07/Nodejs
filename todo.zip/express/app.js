const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));

let studentData = [
  { id: 1, name: "rakhi" },
  { id: 2, name: "mahi" },
];

// Render Home Page
app.get("/", (req, res) => {
  res.render("home", { studentData });
});

// Add New Student
app.post("/add", (req, res) => {
  const { id, name } = req.body;
  studentData.push({ id: parseInt(id), name });
  res.redirect("/");
});

// Edit Student Data
app.post("/edit/:index", (req, res) => {
  const index = parseInt(req.params.index);
  const { id, name } = req.body;

  if (index >= 0 && index < studentData.length) {
    studentData[index] = { id: parseInt(id), name }; 
  }

  res.redirect("/");
});

// Delete Student
app.get("/delete/:index", (req, res) => {
  const index = parseInt(req.params.index);

  if (index >= 0 && index < studentData.length) {
    studentData.splice(index, 1);
  }

  res.redirect("/");
});

// Start Server
app.listen(7800, () => {
  console.log("Server is running on http://localhost:7800");
});